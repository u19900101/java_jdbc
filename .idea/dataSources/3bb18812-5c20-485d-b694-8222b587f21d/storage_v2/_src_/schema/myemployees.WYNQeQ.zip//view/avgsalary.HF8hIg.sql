create view avgsalary as
select avg(`myemployees`.`employees`.`salary`) AS `avgs`,`myemployees`.`employees`.`job_id` AS `job_id`
from `myemployees`.`employees`
group by `myemployees`.`employees`.`job_id`
order by `avgs` desc
limit 1;

